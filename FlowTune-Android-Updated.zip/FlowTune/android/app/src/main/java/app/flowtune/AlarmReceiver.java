package app.flowtune;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("taskId");
        String title = intent.getStringExtra("title");
        AlarmNotifications.show(context, id == null ? "task" : id, title);
    }
}
