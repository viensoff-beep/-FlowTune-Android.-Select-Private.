package app.flowtune;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private static final int REQ_PERMS = 41;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new NativeBridge(this), "FlowTuneNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/www/index.html");
        requestRuntimePermissions();
        AlarmNotifications.createChannel(this);
    }
    private void requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            java.util.ArrayList<String> ask = new java.util.ArrayList<>();
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) ask.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) ask.add(Manifest.permission.POST_NOTIFICATIONS);
            if (!ask.isEmpty()) requestPermissions(ask.toArray(new String[0]), REQ_PERMS);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERMS);
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS && web != null) web.postDelayed(() ->
            web.evaluateJavascript("window.flowTuneScanDeviceAudio && window.flowTuneScanDeviceAudio();", null), 700);
    }
    @Override protected void onResume() {
        super.onResume();
        if (web != null) web.postDelayed(() ->
            web.evaluateJavascript("window.flowTuneRescheduleAlarms && window.flowTuneRescheduleAlarms();", null), 500);
    }
    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    public static class NativeBridge {
        private final MainActivity activity;
        NativeBridge(MainActivity a) { activity = a; }

        @JavascriptInterface public String scanAudioLibrary() {
            JSONArray result = new JSONArray();
            if (!hasAudioPermission()) return result.toString();
            String[] projection = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.MIME_TYPE};
            String selection = null;
            try (Cursor c = activity.getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, selection, null,
                    MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
                if (c == null) return result.toString();
                File dir = new File(activity.getFilesDir(), "device-audio");
                if (!dir.exists()) dir.mkdirs();
                while (c.moveToNext()) {
                    long mediaId = c.getLong(0);
                    Uri content = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, mediaId);
                    String ext = extension(c.getString(5));
                    File dest = new File(dir, mediaId + ext);
                    if (!dest.exists() || dest.length() == 0) copy(content, dest);
                    if (!dest.exists() || dest.length() == 0) continue;
                    JSONObject item = new JSONObject();
                    item.put("id", String.valueOf(mediaId));
                    item.put("title", safe(c.getString(1)));
                    item.put("artist", safe(c.getString(2)));
                    item.put("album", safe(c.getString(3)));
                    item.put("duration", Math.max(0, c.getLong(4) / 1000));
                    item.put("mime", safe(c.getString(5)));
                    item.put("url", Uri.fromFile(dest).toString());
                    result.put(item);
                }
            } catch (Exception ignored) {}
            return result.toString();
        }
        private boolean hasAudioPermission() {
            if (Build.VERSION.SDK_INT >= 33) return activity.checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED;
            return Build.VERSION.SDK_INT < 23 || activity.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        private void copy(Uri source, File dest) {
            try (InputStream in = activity.getContentResolver().openInputStream(source);
                 FileOutputStream out = new FileOutputStream(dest)) {
                if (in == null) return;
                byte[] buf = new byte[64 * 1024]; int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } catch (Exception e) { dest.delete(); }
        }
        private static String safe(String s) { return s == null || s.equals("<unknown>") ? "" : s; }
        private static String extension(String mime) {
            if (mime == null) return ".audio";
            if (mime.contains("mpeg")) return ".mp3";
            if (mime.contains("mp4") || mime.contains("m4a")) return ".m4a";
            if (mime.contains("ogg")) return ".ogg";
            if (mime.contains("flac")) return ".flac";
            if (mime.contains("wav")) return ".wav";
            return ".audio";
        }

        @JavascriptInterface public String scheduleTaskAlarm(String id, String title, long at) {
            try {
                if (at <= System.currentTimeMillis()) return "time-in-past";
                if (Build.VERSION.SDK_INT >= 31) {
                    AlarmManager am = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
                    if (!am.canScheduleExactAlarms()) return "exact-alarm-permission-required";
                }
                AlarmNotifications.schedule(activity, id, title, at);
                return "ok";
            } catch (Exception e) { return "error"; }
        }
        @JavascriptInterface public void requestExactAlarmPermission() {
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager am = (AlarmManager) activity.getSystemService(Context.ALARM_SERVICE);
                if (!am.canScheduleExactAlarms()) {
                    Intent settings = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                        Uri.parse("package:" + activity.getPackageName()));
                    activity.startActivity(settings);
                }
            }
        }
        @JavascriptInterface public void cancelTaskAlarm(String id) { AlarmNotifications.cancel(activity, id); }
    }
}
