package app.flowtune;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Map;

public final class AlarmNotifications {
    static final String CHANNEL = "flowtune_task_alarms";
    private static final String PREFS = "flowtune_alarms";
    static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Task alarms", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("On-time reminders for FlowTune tasks");
            channel.enableVibration(true);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }
    static int code(String id) { return id.hashCode() & 0x7fffffff; }
    static PendingIntent alarmIntent(Context c, String id, String title) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction("app.flowtune.TASK_ALARM." + id);
        i.putExtra("taskId", id); i.putExtra("title", title);
        return PendingIntent.getBroadcast(c, code(id), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    static void schedule(Context c, String id, String title, long at) {
        createChannel(c);
        c.getSharedPreferences(PREFS, 0).edit().putString("title:" + id, title).putLong("time:" + id, at).apply();
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = alarmIntent(c, id, title);
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
        else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
    }
    static void cancel(Context c, String id) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = alarmIntent(c, id, "");
        am.cancel(pi); pi.cancel();
        c.getSharedPreferences(PREFS, 0).edit().remove("title:" + id).remove("time:" + id).apply();
    }
    static void rescheduleAll(Context c) {
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager manager = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if (!manager.canScheduleExactAlarms()) return;
        }
        Map<String, ?> all = c.getSharedPreferences(PREFS, 0).getAll();
        for (String key : all.keySet()) {
            if (!key.startsWith("time:")) continue;
            String id = key.substring(5);
            long at = ((Number)all.get(key)).longValue();
            String title = c.getSharedPreferences(PREFS, 0).getString("title:" + id, "Task due");
            if (at > System.currentTimeMillis()) schedule(c, id, title, at);
        }
    }
    static void show(Context c, String id, String title) {
        createChannel(c);
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(c, code(id), open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("FlowTune · Task reminder")
            .setContentText(title == null || title.isEmpty() ? "Your task is due now" : title)
            .setStyle(new Notification.BigTextStyle().bigText(title == null ? "Your task is due now" : title))
            .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX)
            .setAutoCancel(true).setContentIntent(content).setDefaults(Notification.DEFAULT_ALL);
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(code(id), b.build());
        c.getSharedPreferences(PREFS, 0).edit().remove("title:" + id).remove("time:" + id).apply();
    }
}
