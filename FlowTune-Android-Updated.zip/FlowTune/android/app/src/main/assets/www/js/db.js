/* IndexedDB persistence layer. All records remain on this device. */
const DB = (() => {
  const NAME = "flowtune-local", VERSION = 3;
  let database;
  const stores = ["tasks", "tracks", "playlists", "sessions", "categories"];
  function open() {
    return new Promise((resolve, reject) => {
      if (database) return resolve(database);
      if (!("indexedDB" in window)) return reject(new Error("IndexedDB is unavailable in this browser."));
      const request = indexedDB.open(NAME, VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        for (const name of stores) if (!db.objectStoreNames.contains(name)) db.createObjectStore(name, { keyPath: "id" });
      };
      request.onsuccess = () => { database = request.result; database.onversionchange = () => database.close(); resolve(database); };
      request.onerror = () => reject(request.error || new Error("Could not open local storage."));
      request.onblocked = () => reject(new Error("Close other FlowTune tabs to finish updating storage."));
    });
  }
  function run(store, mode, action) {
    return open().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(store, mode), req = action(tx.objectStore(store));
      let result;
      if (req) { req.onsuccess = () => { result = req.result; }; req.onerror = () => reject(req.error); }
      tx.oncomplete = () => resolve(result);
      tx.onerror = () => reject(tx.error || new Error("Storage operation failed."));
      tx.onabort = () => reject(tx.error || new Error("Storage operation was cancelled."));
    }));
  }
  return {
    open, stores,
    all: s => run(s, "readonly", o => o.getAll()),
    get: (s, id) => run(s, "readonly", o => o.get(id)),
    put: (s, v) => run(s, "readwrite", o => o.put(v)),
    del: (s, id) => run(s, "readwrite", o => o.delete(id)),
    clear: s => run(s, "readwrite", o => o.clear()),
    count: s => run(s, "readonly", o => o.count())
  };
})();
