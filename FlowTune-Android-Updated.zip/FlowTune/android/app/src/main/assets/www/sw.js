const CACHE = "flowtune-shell-v2";
const CORE = ["./","./index.html","./manifest.json","./css/style.css","./js/db.js","./js/icons.js","./js/app.js","./assets/icons/icon.svg","./assets/icons/icon-192.png","./assets/icons/icon-512.png"];
self.addEventListener("install", event => { event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(CORE))); self.skipWaiting(); });
self.addEventListener("activate", event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key))))); self.clients.claim(); });
self.addEventListener("fetch", event => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (req.mode === "navigate") {
    event.respondWith(fetch(req).then(response => { const copy=response.clone(); caches.open(CACHE).then(c=>c.put("./index.html",copy)); return response; }).catch(() => caches.match("./index.html")));
    return;
  }
  event.respondWith(caches.match(req).then(cached => cached || fetch(req).then(response => {
    if (response.ok) { const copy=response.clone(); caches.open(CACHE).then(c=>c.put(req,copy)); }
    return response;
  })));
});
