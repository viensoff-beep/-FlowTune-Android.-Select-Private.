# FlowTune 2.0

FlowTune is a local-first music and productivity PWA. It has no account system, backend, hosted database, or server-side user data. Tasks, imported audio, playlists, lyrics, focus sessions and preferences are stored in the browser on the device.

## Included features

- Task creation, editing, completion, deletion, due dates, priority, categories, repeat schedules and subtasks/checklists.
- Search, filters, overdue indicators, sorting and task history through completed tasks.
- Local audio import and playback, favourites, queue, shuffle, repeat, seek, volume and playback speed.
- Playlists and per-track LRC lyric import with timestamp synchronisation and manual lyric seeking.
- Pomodoro focus timer, short/long breaks, session history, daily focus totals, task linking and optional sound.
- Optional Jamendo discovery using a public client ID.
- IndexedDB persistence, JSON backup/restore (including imported audio blobs), theme/accent settings and PWA offline shell caching.

## Run locally

A PWA service worker requires HTTPS or localhost. Do not open `index.html` directly with `file://`.

### Option A — Python

1. Extract the `FlowTune` folder.
2. Open a terminal in that folder.
3. Run `python -m http.server 8000`.
4. Visit `http://localhost:8000` in Chrome, Firefox or Edge.

### Option B — VS Code

Install the Live Server extension, open the `FlowTune` folder, right-click `index.html`, and choose **Open with Live Server**.

## Deploy with GitHub Pages

1. Create a GitHub repository.
2. Upload the *contents* of this folder so `index.html` is at the repository root.
3. In repository Settings → Pages, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
4. Wait for deployment and open the published HTTPS URL.
5. Check that the URL loads the app and that the browser reports the service worker as active.

If deploying to a project subpath, keep `manifest.json` `start_url` and `scope` relative (`./`) as provided.

## Install on Android

1. Deploy FlowTune to GitHub Pages (or another HTTPS host).
2. Open the HTTPS address in Chrome on Android.
3. Open Chrome's three-dot menu and choose **Install app** or **Add to Home screen** (the exact label varies by Chrome version).
4. Launch FlowTune from the new home-screen icon.
5. Import audio files using **Music → Import music**. Grant file access through the Android picker.

The web app is installable as a PWA. To create a standalone Android APK, see **Generate an APK with PWABuilder** below.

### Generate an APK with PWABuilder

1. Publish FlowTune to an HTTPS URL first. PWABuilder needs to inspect the live manifest and service worker.
2. Visit [https://www.pwabuilder.com/](https://www.pwabuilder.com/) and enter the published FlowTune URL.
3. Run the PWA checks. Fix any manifest, icon, HTTPS or service-worker issues it reports.
4. Choose **Package for stores** → **Android** and follow the current Android packaging flow.
5. Download the generated Android project/package. If PWABuilder provides a Bubblewrap/TWA project, open it in Android Studio, allow Gradle sync, and build a signed APK or AAB.
6. For local APK builds in Android Studio, use **Build → Generate Signed Bundle / APK → APK**. Create and safely store a signing key. Do not share the keystore or its passwords.
7. Install the signed APK on your Android device. Android may ask you to allow installation from the browser or file manager used to open it.

PWABuilder's screens and Android packaging requirements can change. Follow the current prompts and use its validation output rather than assuming a generated package is already signed.

## Import music and playlists

- Open **Music → Import music** and choose audio files from your device.
- Browser audio support varies. MP3, AAC/M4A, WAV, OGG/Opus and WebM audio are commonly supported depending on the browser and Android build. FLAC support varies.
- FlowTune stores the imported audio `Blob` in IndexedDB so the library can survive reloads and offline use.
- Use the heart control to mark favourites.
- Use the plus control on a track to add it to a playlist. Create playlists in the Playlists section.

## Synced lyrics

1. Select a song from Music.
2. Use its lyrics control or open Lyrics and choose **Import .lrc**.
3. Select an LRC file containing timestamps such as `[00:12.50]A lyric line`.
4. Lyrics highlight as playback advances. Tap a lyric line to seek to its timestamp.
5. Use the +0.5s / −0.5s controls to adjust sync offset during the current session.

LRC is plain text. Lines without valid timestamps are ignored. Lyrics are associated with the local track record.

## Jamendo

1. Create a Jamendo developer application and obtain its public `client_id` from the Jamendo developer portal.
2. Open Settings → Jamendo discovery and paste the public client ID.
3. Save it, then choose Discover music while online.

The application uses Jamendo's public tracks API endpoint and requests preview audio. API availability, terms, rate limits, licensing and preview playback are controlled by Jamendo. The client ID is not a private API secret. Do not paste secret keys into the app. If no client ID or internet connection is available, discovery remains unavailable; local music continues to work.

## Offline storage, backup and restore

- The service worker caches the application shell after the first successful online load.
- Tasks, music, playlists, lyrics and focus sessions use IndexedDB. Preferences use localStorage.
- Imported audio is stored in browser-managed device storage. Browser storage quotas vary by device and browser. Users or the operating system can clear site data; some browsers may evict storage under pressure.
- FlowTune requests persistent storage when the browser supports it, but this request is not guaranteed.
- **Settings → Export backup** creates a JSON backup including audio blobs. Large music libraries can create very large files and take time.
- **Settings → Import backup** restores records from a FlowTune JSON backup. Existing records with matching IDs are replaced; unrelated records remain.
- Export backups periodically and keep a copy outside the browser.

## Reminders and browser limitations

- In-app due-date checks run while the app is active. Web notifications require browser permission and support.
- A browser or Android may suspend or terminate a PWA in the background. Therefore, reminders are best-effort and are not guaranteed alarms.
- Browser audio codecs differ. A file may import but fail to decode on a particular browser.
- Local storage is scoped to the origin. Moving from localhost to GitHub Pages creates a different storage space.
- Jamendo discovery requires internet. All local productivity and library features are designed to work offline after the app shell has been cached.
- A service worker does not run when the app is opened from `file://`; use localhost or HTTPS.
- The app has no server synchronisation. Data does not automatically move between devices.

## Privacy

FlowTune does not create accounts or send tasks, local audio, lyrics, playlists, or focus history to a FlowTune backend. Optional Jamendo requests send the configured public client ID and API request parameters to Jamendo. Google Fonts are referenced for typography when online; system fonts are used as fallback. For a fully network-silent deployment, remove the Google Fonts `@import` from `css/style.css`.

## Project structure

```text
FlowTune/
├── index.html
├── manifest.json
├── sw.js
├── README.md
├── css/
│   └── style.css
├── js/
│   ├── app.js
│   ├── db.js
│   └── icons.js
└── assets/
    └── icons/
        ├── icon.svg
        ├── icon-192.png
        └── icon-512.png
```


## Android native build (FlowTune 2.1)

The `android/` folder is a native Android wrapper for the same FlowTune web UI. It adds two Android-only capabilities that a normal PWA cannot reliably provide:

- **Task alarms:** enable “Ring with an alarm notification” when creating/editing a task. Android schedules an exact wake-up alarm and posts a high-priority notification with sound/vibration. Alarms are restored after device reboot. Android may ask you to allow “Alarms & reminders” and notifications.
- **Automatic audio library scan:** on Android launch, FlowTune requests audio-library permission and scans the device's music collection using MediaStore. Tracks are copied into FlowTune's private app storage and indexed with title, artist, album and duration. Use **Scan device** in Music to refresh after adding files. Imported device tracks are available offline inside FlowTune. Removing FlowTune or clearing its app data removes these private copies.

### Build the APK
1. Open the `android/` folder in Android Studio (Giraffe or newer; JDK 17).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated `android/app/build/outputs/apk/debug/app-debug.apk` on your Android phone.

This ZIP is source code, not a prebuilt/signed APK. The native wrapper needs to be built with Android Studio/Android SDK. The PWA deployment remains available, but exact alarms and full MediaStore scanning work only in the native Android app. The web fallback can show reminders only while its page is active and cannot scan the entire device library automatically.
